/*
 * ER/Studio Data Architect SQL Code Generation
 * Project :      Iowa_Liquor_Sales_Dimensional_Model.DM1
 *
 * Date Created : Sunday, April 02, 2023 20:53:15
 * Target DBMS : Microsoft SQL Server 2019
 */

USE IOWA
go
/* 
 * TABLE: Dim_iowa_city 
 */

CREATE TABLE Dim_iowa_city(
    City_SK          int            IDENTITY(1,1),
    City             varchar(24)    NULL,
    FIPS             int            NULL,
    DI_JobID         varchar(20)    NULL,
    DI_CreateDate    datetime       DEFAULT (getdate()) NOT NULL,
    CONSTRAINT PK__Dim_iowa__DE9C5FF27C872AA4 PRIMARY KEY CLUSTERED (City_SK)
)

go


IF OBJECT_ID('Dim_iowa_city') IS NOT NULL
    PRINT '<<< CREATED TABLE Dim_iowa_city >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Dim_iowa_city >>>'
go

/* 
 * TABLE: Dim_iowa_county 
 */

CREATE TABLE Dim_iowa_county(
    County_SK        int            IDENTITY(1,1),
    County           varchar(80)    NULL,
    FIPS             int            NULL,
    DI_JobID         varchar(20)    NULL,
    DI_CreateDate    datetime       DEFAULT (getdate()) NOT NULL,
    CONSTRAINT PK__Dim_iowa__C71128402A7A7C8E PRIMARY KEY CLUSTERED (County_SK)
)

go


IF OBJECT_ID('Dim_iowa_county') IS NOT NULL
    PRINT '<<< CREATED TABLE Dim_iowa_county >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Dim_iowa_county >>>'
go

/* 
 * TABLE: Dim_iowa_liquor_Product_Categories 
 */

CREATE TABLE Dim_iowa_liquor_Product_Categories(
    Category_SK        int            IDENTITY(1,1),
    Category_Number    int            NOT NULL,
    Category_Name      varchar(40)    NULL,
    DI_JobID           varchar(20)    NULL,
    DI_CreateDate      datetime       DEFAULT (getdate()) NOT NULL,
    CONSTRAINT PK__Dim_iowa__6DB0DA1AB7BE8276 PRIMARY KEY CLUSTERED (Category_SK)
)

go


IF OBJECT_ID('Dim_iowa_liquor_Product_Categories') IS NOT NULL
    PRINT '<<< CREATED TABLE Dim_iowa_liquor_Product_Categories >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Dim_iowa_liquor_Product_Categories >>>'
go

/* 
 * TABLE: Dim_iowa_liquor_Products 
 */

CREATE TABLE Dim_iowa_liquor_Products(
    Item_SK                int               NOT NULL,
    Item_Number            int               NOT NULL,
    Item_Number_C          varchar(20)       NULL,
    Item_Description       varchar(80)       NULL,
    Category_SK            int               NULL,
    Vendor_SK              int               NOT NULL,
    Bottle_Volume_ml       int               NULL,
    Pack                   int               NULL,
    Inner_Pack             int               NULL,
    Age                    int               NULL,
    Proof                  int               NULL,
    List_Date              date              NULL,
    UPC                    varchar(20)       NULL,
    SCC                    varchar(20)       NULL,
    State_Bottle_Cost      decimal(19, 4)    NULL,
    State_Case_Cost        decimal(19, 4)    NULL,
    State_Bottle_Retail    decimal(19, 4)    NULL,
    Report_Date            date              NULL,
    DI_JobID               varchar(20)       NULL,
    DI_CreateDate          datetime          DEFAULT (getdate()) NOT NULL,
    CONSTRAINT PK__Dim_iowa__3FB53F491BDE3523 PRIMARY KEY CLUSTERED (Item_SK)
)

go


IF OBJECT_ID('Dim_iowa_liquor_Products') IS NOT NULL
    PRINT '<<< CREATED TABLE Dim_iowa_liquor_Products >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Dim_iowa_liquor_Products >>>'
go

/* 
 * TABLE: Dim_Iowa_Liquor_Stores 
 */

CREATE TABLE Dim_Iowa_Liquor_Stores(
    Store_SK         int            NOT NULL,
    Store_ID         int            NOT NULL,
    Store_Name       varchar(80)    NULL,
    Store_Status     char(1)        NULL,
    Address          varchar(80)    NULL,
    Zip_Code         int            NULL,
    City_SK          int            NOT NULL,
    County_SK        int            NOT NULL,
    Report_Date      datetime       NULL,
    DI_JobID         varchar(20)    NULL,
    DI_CreateDate    datetime       DEFAULT (getdate()) NOT NULL,
    CONSTRAINT PK__Dim_Iowa__A0F109D0BBD7FB09 PRIMARY KEY CLUSTERED (Store_SK)
)

go


IF OBJECT_ID('Dim_Iowa_Liquor_Stores') IS NOT NULL
    PRINT '<<< CREATED TABLE Dim_Iowa_Liquor_Stores >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Dim_Iowa_Liquor_Stores >>>'
go

/* 
 * TABLE: Dim_iowa_liquor_Vendors 
 */

CREATE TABLE Dim_iowa_liquor_Vendors(
    Vendor_SK        int            NOT NULL,
    Vendor_Number    int            NOT NULL,
    Vendor_Name      varchar(80)    NULL,
    DI_JobID         varchar(20)    NULL,
    DI_CreateDate    datetime       DEFAULT (getdate()) NOT NULL,
    CONSTRAINT PK__Dim_iowa__D9C32F90DA15BE18 PRIMARY KEY CLUSTERED (Vendor_SK)
)

go


IF OBJECT_ID('Dim_iowa_liquor_Vendors') IS NOT NULL
    PRINT '<<< CREATED TABLE Dim_iowa_liquor_Vendors >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE Dim_iowa_liquor_Vendors >>>'
go

/* 
 * TABLE: FCT_iowa_city_population_by_year 
 */

CREATE TABLE FCT_iowa_city_population_by_year(
    City_Pop_SK        int            NOT NULL,
    City_SK            int            NOT NULL,
    City               varchar(24)    NULL,
    FIPS               int            NULL,
    DateAsOf           datetime       NULL,
    Population_Year    int            NULL,
    Population         int            NULL,
    DI_JobID           varchar(20)    NULL,
    DI_CreateDate      datetime       NULL,
    CONSTRAINT PK__FCT_iowa__6840149B61FC4B1B PRIMARY KEY CLUSTERED (City_Pop_SK)
)

go


IF OBJECT_ID('FCT_iowa_city_population_by_year') IS NOT NULL
    PRINT '<<< CREATED TABLE FCT_iowa_city_population_by_year >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE FCT_iowa_city_population_by_year >>>'
go

/* 
 * TABLE: FCT_iowa_county_population_by_year 
 */

CREATE TABLE FCT_iowa_county_population_by_year(
    County_Pop_SK      int            IDENTITY(1,1),
    County_SK          int            NOT NULL,
    County             varchar(80)    NULL,
    FIPS               int            NULL,
    DateAsOf           date           NULL,
    Population_Year    int            NULL,
    Population         int            NULL,
    DI_JobID           varchar(20)    NULL,
    DI_CreateDate      datetime       DEFAULT (getdate()) NOT NULL,
    CONSTRAINT PK__FCT_iowa__99C03905BD1CE7BB PRIMARY KEY CLUSTERED (County_Pop_SK)
)

go


IF OBJECT_ID('FCT_iowa_county_population_by_year') IS NOT NULL
    PRINT '<<< CREATED TABLE FCT_iowa_county_population_by_year >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE FCT_iowa_county_population_by_year >>>'
go

/* 
 * TABLE: fct_iowa_liquor_sales_invoice_header 
 */

CREATE TABLE fct_iowa_liquor_sales_invoice_header(
    Invoice_Number                 varchar(24)       NOT NULL,
    Invoice_Date                   datetime          NOT NULL,
    InvoiceDate_SK                 int               NOT NULL,
    Store_SK                       int               NULL,
    Store_Number                   int               NULL,
    Invoice_Bottles_Sold           int               NULL,
    Invoice_Sale_Dollars           numeric(19, 4)    NULL,
    Invoice_Volume_Sold_Liters     numeric(19, 4)    NULL,
    Invoice_Volume_Sold_Gallons    numeric(19, 4)    NULL,
    DI_JobID                       varchar(20)       NULL,
    DI_CreateDate                  datetime          DEFAULT (getdate()) NOT NULL,
    CONSTRAINT PK__fct_iowa__7C0BEC68A924B519 PRIMARY KEY CLUSTERED (Invoice_Number)
)

go


IF OBJECT_ID('fct_iowa_liquor_sales_invoice_header') IS NOT NULL
    PRINT '<<< CREATED TABLE fct_iowa_liquor_sales_invoice_header >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE fct_iowa_liquor_sales_invoice_header >>>'
go

/* 
 * TABLE: fct_iowa_liquor_sales_invoice_lineitem 
 */

CREATE TABLE fct_iowa_liquor_sales_invoice_lineitem(
    Invoice_Item_Number      varchar(24)       NOT NULL,
    Invoice_Number           varchar(24)       NOT NULL,
    Invoice_Number_LineNo    int               NULL,
    Item_SK                  int               NOT NULL,
    Item_Number              varchar(24)       NULL,
    Pack                     int               NULL,
    Bottle_Volume_ml         int               NULL,
    State_Bottle_Cost        numeric(19, 4)    NULL,
    State_Bottle_Retail      numeric(19, 4)    NULL,
    Bottles_Sold             int               NULL,
    Sale_Dollars             numeric(19, 4)    NULL,
    Volume_Sold_Liters       numeric(19, 4)    NULL,
    Volume_Sold_Gallons      numeric(19, 4)    NULL,
    DI_JobID                 varchar(20)       NULL,
    DI_CreateDate            datetime          DEFAULT (getdate()) NOT NULL,
    CONSTRAINT PK__fct_iowa__13D21278575CC7A2 PRIMARY KEY CLUSTERED (Invoice_Item_Number)
)

go


IF OBJECT_ID('fct_iowa_liquor_sales_invoice_lineitem') IS NOT NULL
    PRINT '<<< CREATED TABLE fct_iowa_liquor_sales_invoice_lineitem >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE fct_iowa_liquor_sales_invoice_lineitem >>>'
go

/* 
 * INDEX: Ref34 
 */

CREATE INDEX Ref34 ON Dim_iowa_liquor_Products(Category_SK)
go
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id=OBJECT_ID('Dim_iowa_liquor_Products') AND name='Ref34')
    PRINT '<<< CREATED INDEX Dim_iowa_liquor_Products.Ref34 >>>'
ELSE
    PRINT '<<< FAILED CREATING INDEX Dim_iowa_liquor_Products.Ref34 >>>'
go

/* 
 * INDEX: Ref67 
 */

CREATE INDEX Ref67 ON Dim_iowa_liquor_Products(Vendor_SK)
go
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id=OBJECT_ID('Dim_iowa_liquor_Products') AND name='Ref67')
    PRINT '<<< CREATED INDEX Dim_iowa_liquor_Products.Ref67 >>>'
ELSE
    PRINT '<<< FAILED CREATING INDEX Dim_iowa_liquor_Products.Ref67 >>>'
go

/* 
 * INDEX: Ref11 
 */

CREATE INDEX Ref11 ON Dim_Iowa_Liquor_Stores(City_SK)
go
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id=OBJECT_ID('Dim_Iowa_Liquor_Stores') AND name='Ref11')
    PRINT '<<< CREATED INDEX Dim_Iowa_Liquor_Stores.Ref11 >>>'
ELSE
    PRINT '<<< FAILED CREATING INDEX Dim_Iowa_Liquor_Stores.Ref11 >>>'
go

/* 
 * INDEX: Ref23 
 */

CREATE INDEX Ref23 ON Dim_Iowa_Liquor_Stores(County_SK)
go
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id=OBJECT_ID('Dim_Iowa_Liquor_Stores') AND name='Ref23')
    PRINT '<<< CREATED INDEX Dim_Iowa_Liquor_Stores.Ref23 >>>'
ELSE
    PRINT '<<< FAILED CREATING INDEX Dim_Iowa_Liquor_Stores.Ref23 >>>'
go

/* 
 * INDEX: Ref112 
 */

CREATE INDEX Ref112 ON FCT_iowa_city_population_by_year(City_SK)
go
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id=OBJECT_ID('FCT_iowa_city_population_by_year') AND name='Ref112')
    PRINT '<<< CREATED INDEX FCT_iowa_city_population_by_year.Ref112 >>>'
ELSE
    PRINT '<<< FAILED CREATING INDEX FCT_iowa_city_population_by_year.Ref112 >>>'
go

/* 
 * INDEX: Ref22 
 */

CREATE INDEX Ref22 ON FCT_iowa_county_population_by_year(County_SK)
go
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id=OBJECT_ID('FCT_iowa_county_population_by_year') AND name='Ref22')
    PRINT '<<< CREATED INDEX FCT_iowa_county_population_by_year.Ref22 >>>'
ELSE
    PRINT '<<< FAILED CREATING INDEX FCT_iowa_county_population_by_year.Ref22 >>>'
go

/* 
 * INDEX: Ref56 
 */

CREATE INDEX Ref56 ON fct_iowa_liquor_sales_invoice_header(Store_SK)
go
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id=OBJECT_ID('fct_iowa_liquor_sales_invoice_header') AND name='Ref56')
    PRINT '<<< CREATED INDEX fct_iowa_liquor_sales_invoice_header.Ref56 >>>'
ELSE
    PRINT '<<< FAILED CREATING INDEX fct_iowa_liquor_sales_invoice_header.Ref56 >>>'
go

/* 
 * INDEX: Ref45 
 */

CREATE INDEX Ref45 ON fct_iowa_liquor_sales_invoice_lineitem(Item_SK)
go
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id=OBJECT_ID('fct_iowa_liquor_sales_invoice_lineitem') AND name='Ref45')
    PRINT '<<< CREATED INDEX fct_iowa_liquor_sales_invoice_lineitem.Ref45 >>>'
ELSE
    PRINT '<<< FAILED CREATING INDEX fct_iowa_liquor_sales_invoice_lineitem.Ref45 >>>'
go

/* 
 * INDEX: Ref913 
 */

CREATE INDEX Ref913 ON fct_iowa_liquor_sales_invoice_lineitem(Invoice_Number)
go
IF EXISTS (SELECT * FROM sys.indexes WHERE object_id=OBJECT_ID('fct_iowa_liquor_sales_invoice_lineitem') AND name='Ref913')
    PRINT '<<< CREATED INDEX fct_iowa_liquor_sales_invoice_lineitem.Ref913 >>>'
ELSE
    PRINT '<<< FAILED CREATING INDEX fct_iowa_liquor_sales_invoice_lineitem.Ref913 >>>'
go

/* 
 * TABLE: Dim_iowa_liquor_Products 
 */

ALTER TABLE Dim_iowa_liquor_Products ADD CONSTRAINT RefDim_iowa_liquor_Product_Categories4 
    FOREIGN KEY (Category_SK)
    REFERENCES Dim_iowa_liquor_Product_Categories(Category_SK)
go

ALTER TABLE Dim_iowa_liquor_Products ADD CONSTRAINT RefDim_iowa_liquor_Vendors7 
    FOREIGN KEY (Vendor_SK)
    REFERENCES Dim_iowa_liquor_Vendors(Vendor_SK)
go


/* 
 * TABLE: Dim_Iowa_Liquor_Stores 
 */

ALTER TABLE Dim_Iowa_Liquor_Stores ADD CONSTRAINT RefDim_iowa_city1 
    FOREIGN KEY (City_SK)
    REFERENCES Dim_iowa_city(City_SK)
go

ALTER TABLE Dim_Iowa_Liquor_Stores ADD CONSTRAINT RefDim_iowa_county3 
    FOREIGN KEY (County_SK)
    REFERENCES Dim_iowa_county(County_SK)
go


/* 
 * TABLE: FCT_iowa_city_population_by_year 
 */

ALTER TABLE FCT_iowa_city_population_by_year ADD CONSTRAINT RefDim_iowa_city12 
    FOREIGN KEY (City_SK)
    REFERENCES Dim_iowa_city(City_SK)
go


/* 
 * TABLE: FCT_iowa_county_population_by_year 
 */

ALTER TABLE FCT_iowa_county_population_by_year ADD CONSTRAINT RefDim_iowa_county2 
    FOREIGN KEY (County_SK)
    REFERENCES Dim_iowa_county(County_SK)
go


/* 
 * TABLE: fct_iowa_liquor_sales_invoice_header 
 */

ALTER TABLE fct_iowa_liquor_sales_invoice_header ADD CONSTRAINT RefDim_Iowa_Liquor_Stores6 
    FOREIGN KEY (Store_SK)
    REFERENCES Dim_Iowa_Liquor_Stores(Store_SK)
go


/* 
 * TABLE: fct_iowa_liquor_sales_invoice_lineitem 
 */

ALTER TABLE fct_iowa_liquor_sales_invoice_lineitem ADD CONSTRAINT RefDim_iowa_liquor_Products5 
    FOREIGN KEY (Item_SK)
    REFERENCES Dim_iowa_liquor_Products(Item_SK)
go

ALTER TABLE fct_iowa_liquor_sales_invoice_lineitem ADD CONSTRAINT Reffct_iowa_liquor_sales_invoice_header13 
    FOREIGN KEY (Invoice_Number)
    REFERENCES fct_iowa_liquor_sales_invoice_header(Invoice_Number)
go


